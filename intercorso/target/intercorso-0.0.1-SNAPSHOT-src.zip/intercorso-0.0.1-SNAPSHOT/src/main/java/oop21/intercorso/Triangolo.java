package oop21.intercorso;


public class Triangolo extends poligono {
	
	public Triangolo() {
		super(3);
	}
	
}
