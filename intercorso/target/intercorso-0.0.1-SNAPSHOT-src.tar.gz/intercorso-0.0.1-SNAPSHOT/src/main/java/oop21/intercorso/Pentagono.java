package oop21.intercorso;

public class Pentagono extends poligono {
	public Pentagono() {
		super(5);
	}
}
