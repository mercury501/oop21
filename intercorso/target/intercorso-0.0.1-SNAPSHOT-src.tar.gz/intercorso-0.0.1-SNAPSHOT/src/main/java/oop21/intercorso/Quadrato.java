package oop21.intercorso;

public class Quadrato extends poligono {
	public Quadrato() {
		super(4);
	}
}
