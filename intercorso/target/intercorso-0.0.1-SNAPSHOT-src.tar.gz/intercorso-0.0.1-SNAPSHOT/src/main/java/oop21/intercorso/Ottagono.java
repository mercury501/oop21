package oop21.intercorso;

public class Ottagono extends poligono {
	public Ottagono() {
		super(8);
	}
}
